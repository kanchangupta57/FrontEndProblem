import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { MovieComponent } from './movie/movie.component';
import { CommonModule } from "@angular/common";

@NgModule({
  declarations: [ ],
  imports: [
    CommonModule,
    RouterModule.forRoot([
      { path: '', component: MovieComponent },
      { path: 'movies', component: MovieComponent }
    ])
  ],
  exports: [
    RouterModule
  ],
  providers: [],

})
export class AppRoutingModule {}


