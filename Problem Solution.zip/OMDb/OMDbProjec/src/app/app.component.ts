import { Component, OnInit } from '@angular/core';
import * as data from './movie/movieData.json';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'OMDbProject';
  moviedata:any;
  star_wars: string;
  ngOnInit() {
    try {
      this.moviedata=((data as any).default).data;
    }
    catch (err) {
      console.log(err);
    }
  }

}
