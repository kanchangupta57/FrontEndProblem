import { Component, ChangeDetectionStrategy, OnInit, ChangeDetectorRef } from '@angular/core';
import * as data from './movieData.json';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-movie',
  templateUrl: './movie.component.html',
  styleUrls: ['./movie.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MovieComponent implements OnInit{
  movieListdata:any;
  filteredMoviedata:any;
  
  constructor(private route: ActivatedRoute, private cd: ChangeDetectorRef ){}

  ngOnInit() {
    try {
      this.movieListdata=((data as any).default).data;
      this.route.queryParams.subscribe(params => {
        if (params.list=="star_wars") {
          this.filteredMoviedata = this.movieListdata.filter(item=>{
            return item.Title.includes('Star Wars');
          });
        }else if(params.list=="after-dark"){
          this.filteredMoviedata = this.movieListdata.filter(item=>{
            return item.Title.includes('After Dark');
          });
        }else if(params.list=="caught"){
          this.filteredMoviedata = this.movieListdata.filter(item=>{
            return item.Title.includes('Caught');
          });
        }else{
          this.filteredMoviedata = this.movieListdata;
        }
        this.cd.detectChanges();
      })
    }
    catch (err) {
      console.log(err);
    }
  } 
}
