import {Location} from "@angular/common";
import {TestBed, fakeAsync, tick} from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import { MovieComponent } from './movie/movie.component';
import { Router, Routes } from '@angular/router';
import {By} from "@angular/platform-browser";
export const routes: Routes = [
  { path: '', component: MovieComponent },
  { path: 'movies', component: MovieComponent }
];

describe('AppComponent', () => {
  let location: Location;
  let router: Router;
  let fixture;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule.withRoutes(routes)], 
      declarations: [
        AppComponent,
        MovieComponent
      ]
    });

    router = TestBed.get(Router);
    location = TestBed.get(Location);

    fixture = TestBed.createComponent(AppComponent);
    router.initialNavigation();
  });

  it('HTTP call is made: navigate to "movies" redirects you to /movies', fakeAsync(() => { 
    router.navigate(['movies']);
    tick();
    expect(location.path()).toBe('/movies');
  }));

  it('clicking on link/button triggers intended functionality', fakeAsync(() => {
    const link = fixture.debugElement.query(By.css('.star-wars-list')).nativeElement;
    expect(link.innerHTML).not.toBeNull();
    link.click();
    fixture.detectChanges();
    tick();
    fixture.whenStable().then(() => {
      expect(location.path()).toBe('/movies');  
    });    

}))
});
  

describe('AppComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule
      ],
      declarations: [
        AppComponent
      ],
    }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'OMDbProject'`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual('OMDbProject');
  });
});
