import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { MovieComponent } from './movie.component';

describe('MovieComponent', () => {
  let fixture;
  let component:MovieComponent;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule
      ],
      declarations: [
        MovieComponent
      ],
    });
    fixture = TestBed.createComponent(MovieComponent);
    component=fixture.componentInstance;
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(MovieComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it('should print movie data', () => {
    component.ngOnInit();
    expect(component.movieListdata.length).toBe(36);
  });

});
